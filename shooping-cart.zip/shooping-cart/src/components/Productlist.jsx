import { useSelector } from "react-redux";
import ProductCard from "./productcard";

export default function ProductList() {
  const products = useSelector((state) => state.products);

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 mb-8">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
}
