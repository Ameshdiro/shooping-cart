import React from "react";
import { useSelector } from "react-redux";

export default function CartTable() {
  const cart = useSelector((state) => state.cart);
  const total = cart.reduce((sum, item) => sum + item.price, 0);

  return (
    <div className="bg-white p-4 rounded shadow">
      <h2 className="font-bold text-xl mb-2 text-center">Cart</h2>
      <table className="w-full border border-collapse text-center">
        <thead>
          <tr>
            <th className="border px-2 py-1">#</th>
            <th className="border px-2 py-1">Title</th>
            <th className="border px-2 py-1">Price</th>
          </tr>
        </thead>
        <tbody>
          {cart.map((item, index) => (
            <tr key={index}>
              <td className="border px-2 py-1">{index + 1}</td>
              <td className="border px-2 py-1">{item.title}</td>
              <td className="border px-2 py-1">${item.price}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="text-right font-bold mt-2">Total Price = {total} ETB</div>
    </div>
  );
}
