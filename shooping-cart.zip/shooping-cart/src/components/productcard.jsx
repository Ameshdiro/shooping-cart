import React from "react";
import { useDispatch } from "react-redux";
import { addToCart } from "../redux/cartSlice";

export default function ProductCard({ product }) {
  const dispatch = useDispatch();

  return (
    <div className="bg-white p-4 rounded shadow text-center">
      <h2 className="font-bold text-lg mb-2">{product.title}</h2>
      <p className="text-sm mb-2">{product.description}</p>
      <p className="font-semibold mb-4">${product.price} ETB</p>
      <button
        className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700"
        onClick={() => dispatch(addToCart(product))}
      >
        Add to cart
      </button>
    </div>
  );
}
