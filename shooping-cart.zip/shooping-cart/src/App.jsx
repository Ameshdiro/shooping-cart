import React, { useState } from "react";
import ProductList from "./components/productlist";
import CartTable from "./components/carttable";
import AddProductModal from "./components/addproductmodal";

export default function App() {
  const [showModal, setShowModal] = useState(false);

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Shopping Cart</h1>
        <button
          className="bg-blue-500 text-white px-4 py-2 rounded"
          onClick={() => setShowModal(true)}
        >
          Add Product
        </button>
      </div>

      <ProductList />
      <CartTable />

      {showModal && <AddProductModal onClose={() => setShowModal(false)} />}
    </div>
  );
}
