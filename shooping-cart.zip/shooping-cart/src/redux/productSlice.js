import { createSlice } from "@reduxjs/toolkit";

const initialState = [
  { id: 1, title: "Product 1", description: "Desc 1", price: 10 },
  { id: 2, title: "Product 2", description: "Desc 2", price: 15 },
  { id: 3, title: "Product 3", description: "Desc 3", price: 20 },
  { id: 4, title: "Product 4", description: "Desc 4", price: 25 },
];

const productSlice = createSlice({
  name: "products",
  initialState,
  reducers: {
    addProduct: (state, action) => {
      state.push(action.payload);
    },
  },
});

export const { addProduct } = productSlice.actions;
export default productSlice.reducer;
